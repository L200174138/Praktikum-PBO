
import javax.swing.JFrame;


public class BorderDemo {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Assignment with Border Layout");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500,250);
        frame.add(new Border());
        frame.setVisible(true);
    }
}
