import javax.swing.*;
import java.awt.*;

public class Border extends JPanel{
    public Border(){
        setLayout (new BorderLayout());
        
        JLabel l1 = new JLabel("TIMUR");
        JLabel l2 = new JLabel("BARAT");
        JLabel l3 = new JLabel("UTARA");
        JLabel l4 = new JLabel("SELATAN");
        JLabel l5 = new JLabel("PUSAT");
        
        l1.setBackground(Color.pink);
        l2.setBackground(Color.orange);
        l3.setBackground(Color.magenta);
        l4.setBackground(Color.cyan);
        l5.setBackground(Color.darkGray);
        
        l1.setOpaque(true);
        l2.setOpaque(true);
        l3.setOpaque(true);
        l4.setOpaque(true);
        l5.setOpaque(true);
        
        add(l1, BorderLayout.EAST);
        add(l2, BorderLayout.WEST);
        add(l3, BorderLayout.NORTH);
        add(l4, BorderLayout.SOUTH);
        add(l5, BorderLayout.CENTER);
    }
}
