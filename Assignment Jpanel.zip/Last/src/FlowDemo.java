import javax.swing.*;
import java.awt.*;

public class FlowDemo {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Assignment with Flow Layout");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500,100);
        frame.add(new Flow());
        frame.setVisible(true);
    }
}
