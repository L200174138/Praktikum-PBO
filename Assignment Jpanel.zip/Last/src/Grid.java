import javax.swing.*;
import java.awt.*;

public class Grid extends JPanel{
    public Grid(){
        setLayout(new GridLayout (2,3));
        
        JLabel l1 = new JLabel("TIMUR");
        JLabel l2 = new JLabel("BARAT");
        JLabel l3 = new JLabel("SELATAN");
        JLabel l4 = new JLabel("UTARA");
        JLabel l5 = new JLabel("PUSAT");
        
        l1.setBackground(Color.pink);
        l2.setBackground(Color.orange);
        l3.setBackground(Color.magenta);
        l4.setBackground(Color.cyan);
        l5.setBackground(Color.darkGray);
        
        l1.setOpaque(true);
        l2.setOpaque(true);
        l3.setOpaque(true);
        l4.setOpaque(true);
        l5.setOpaque(true);
        
        add(l1);
        add(l2);
        add(l3);
        add(l4);
        add(l5);
    }
}
