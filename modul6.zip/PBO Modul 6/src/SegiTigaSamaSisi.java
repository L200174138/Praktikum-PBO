public class SegiTigaSamaSisi extends SegiTiga{
    double sisi;
    
    public double getSisi(double sisi){
        return this.sisi = sisi;
    }
    
    
    public double alas(double alas){
        return this.alas = alas;
    }
    
    
    public double tinggi(double tinggi){
        return this.tinggi = tinggi;
    }
    
    
    public void hitungLuas(){
        luas = 0.5*alas*tinggi;
    }
    
   
    public double hitungKeliling(){
        return keliling = 3*sisi;
    }
    
    public static void main(String[] args) {
        SegiTigaSamaSisi x = new SegiTigaSamaSisi();
        x.alas(10);
        x.tinggi(15);
        x.getSisi(5);
        x.hitungKeliling();
        x.hitungLuas();
        System.out.println("Luas Segitiga Sama Sisi     : "+x.luas);
        System.out.println("Keliling Segitiga Sama Sisi : "+x.keliling);
    }
}
