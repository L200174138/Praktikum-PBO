public class BangunDatar {
    double luas;
    double keliling;
    
    public void hitungLuas(){
        
    }
    
    public double hitungKeliling(){
        return keliling;
    }
}
