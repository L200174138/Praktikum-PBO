public class Persegi extends BangunDatar{
    double sisi;
    
    public double getSisi(double sisi){
        return this.sisi = sisi;
    }
    
    public void hitungLuas(){
        luas = sisi*sisi;
    }
    
    public double hitungKeliling(){
        return keliling = 4*sisi;
    }
    
    public static void main(String[] args) {
        Persegi x = new Persegi();
        x.getSisi(5);
        x.hitungLuas();
        x.hitungKeliling();
        System.out.println("Luas Persegi     = "+x.luas);
        System.out.println("Keliling Persegi = "+x.keliling);
    }
}
