public class SegitigaSamaKaki extends SegiTiga {
    double sisiMiring;
    
    public double getSisiMiring(double sisiMiring){
        return this.sisiMiring = sisiMiring;
    }
    
    
    public double alas(double alas){
        return this.alas = alas;
    }
    
    
    public double tinggi(double tinggi){
        return this.tinggi = tinggi;
    }
    
    
    public void hitungLuas(){
        luas = 0.5*alas*tinggi;
    }
    
    
    public double hitungKeliling(){
        return keliling = alas + 2*sisiMiring;
    }
    
    public static void main(String[] args) {
        SegitigaSamaKaki x = new SegitigaSamaKaki();
        x.alas(5);
        x.tinggi(14);
        x.getSisiMiring(10);
        x.hitungKeliling();
        x.hitungLuas();
        System.out.println("Luas Segitiga Sama Kaki     : "+x.luas);
        System.out.println("Keliling Segitiga Sama Kaki : "+x.keliling);
    }
}
