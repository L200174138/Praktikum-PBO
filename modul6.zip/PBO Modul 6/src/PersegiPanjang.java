public class PersegiPanjang extends BangunDatar {
    int panjang;
    double lebar;
    
    public int getPanjang(int panjang){
        return this.panjang = panjang;
    }
    
    public double getLebar(double lebar){
        return this.lebar = lebar;
    }
    
    @Override
    public void hitungLuas(){
        luas = panjang*lebar;
    }
    
    @Override
    public double hitungKeliling(){
        return keliling = 2*(panjang+lebar);
    }
    
    public static void main(String[] args) {
        PersegiPanjang x = new PersegiPanjang();
        x.getPanjang(5);
        x.getLebar(10);
        x.hitungLuas();
        x.hitungKeliling();
        System.out.println("Luas Persegi Panjang     = "+x.luas);
        System.out.println("Keliling Persegi Panjang = "+x.keliling);
    }
}
