public class SegiTiga extends BangunDatar{
    double alas;
    double tinggi;
    
    public double alas(double alas){
        return alas;
    }
    
    public double tinggi(double tinggi){
        return tinggi;
    }
}
