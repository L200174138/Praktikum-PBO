package modul.praktikum.pbo;

public class privateModifier {
    private String nama;
    private int umur;
    private void printInfo(){
        System.out.println("private modifier");
    }
}
