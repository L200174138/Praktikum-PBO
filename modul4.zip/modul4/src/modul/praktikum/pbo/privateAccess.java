
package modul.praktikum.pbo;

public class privateAccess {
    public static void main(String[] args) {
        privateModifier a = new privateModifier();
        a.printInfo();
    }
}
