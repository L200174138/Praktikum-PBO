package modul.praktikum.pbo;


public class defaultModifier {
    int a = 1;
    int b = 2;
    int c;
    void jumlah(){
        c = a+b;
        System.out.println(c);
    }
}
