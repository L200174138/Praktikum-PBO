
package modul.praktikum.pbo;

public class publicModifier {
    public int a = 2;
    public int b = 5;
    public int c = 9;
    public void kali(){
        int d = a*b*c;
        System.out.println("Hasil Kali = "+d);
    }
    public void bagi(){
        int d = a/b/c;
        System.out.println("Hasil Bagi = "+d);  
    }
    public void kurang(){
        int d = a-b-c;
        System.out.println("Hasil Pengurangan = "+d);  
    }
    public void jumlah(){
        int d = a+b+c;
        System.out.println("Hasil Penjumlahan = "+d);  
    }
    public void average(){
        int d = a+b+c/3;
        System.out.println("Hasil Rata-Rata = "+d);  
    }
}
