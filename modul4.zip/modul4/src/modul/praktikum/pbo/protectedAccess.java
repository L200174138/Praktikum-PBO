
package modul.praktikum.pbo;

public class protectedAccess {
    public static void main(String[] args) {
        protectedModifier z = new protectedModifier();
        z.sendMessage();
        z.printInfo();
    }
 
}
