
package modul.praktikum.pbo;

public class protectedModifier {
    protected void printInfo(){
        System.out.println("Protected Modifier");
    }
    protected void sendMessage(){
        System.out.println("this is a message");
    }
}
