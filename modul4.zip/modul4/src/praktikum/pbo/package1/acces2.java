
package praktikum.pbo.package1;

import modul.praktikum.pbo.publicModifier;

public class acces2 {
    public static void main(String[] args) {
        publicModifier y = new publicModifier();
        y.jumlah();
        y.kurang();
        y.kali();
        y.bagi();
        y.average();
    }
}
