package praktikum.pbo.package1;

import modul.praktikum.pbo.defaultModifier;

public class acces1 {
    public static void main(String[] args) {
        defaultModifier x = new defaultModifier();
        x.jumlah();
    }
}
