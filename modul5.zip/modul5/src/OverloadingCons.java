import java.util.Date;
public class OverloadingCons {
    int idUser;
    String userName;
    int level;
    Date LastLogin;
    
    public OverloadingCons(){
    
    }
    
    public OverloadingCons(int iduser){
        this.idUser = iduser;
    }
    
    public OverloadingCons(int iduser, String userName){
        this.idUser = iduser;
        this.userName = userName;
    }
    
    public OverloadingCons(int iduser, String userName, int level){
        this.idUser = iduser;
        this.userName = userName;
        this.level = level;
    }
    
    public OverloadingCons(int iduser, String userName, int level, Date LastLogin){
        this.idUser = iduser;
        this.userName = userName;
        this.level = level;
        this.LastLogin = LastLogin;
    }
    
    public void infoku(){
        System.out.println("IDuser      : "+idUser+"\nUsername    : "+userName+"\nLevel       : "+level+"\nLastLogin   : "+LastLogin);
    }
}
