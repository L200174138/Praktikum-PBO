
public class CostumerData {
    String nama;
    String alamat;
    String tglLahir;
    String pekerjaan;
    double gaji;
    
    public CostumerData(){
    
    }
    
    public CostumerData(String nama1){
        this.nama = nama1;
    }
    
    public CostumerData(String nama2, String alamat1){
        this.nama = nama2;
        this.alamat = alamat1;
    }
    
    public CostumerData(String nama3, String alamat2,String tglLahir1){
        this.nama = nama3;
        this.alamat = alamat2;
        this.tglLahir = tglLahir1;
    }
    
    public CostumerData(String nama4, String alamat3,String tglLahir2, String pekerjaan1){
        this.nama = nama4;
        this.alamat = alamat3;
        this.tglLahir = tglLahir2;
        this.pekerjaan = pekerjaan1;
    }
    
    public CostumerData(String nama5, String alamat4,String tglLahir3, String pekerjaan2, double gaji1){
        this.nama = nama5;
        this.alamat = alamat4;
        this.tglLahir = tglLahir3;
        this.pekerjaan = pekerjaan2;
        this.gaji = gaji1;
    }
    
    public void info(){
        System.out.println("Nama        : "+nama+"\nAlamat      : "+alamat+"\nLahir       : "+tglLahir+"\nPekerjaan   : "+pekerjaan+"\nGaji        : Rp "+gaji);
    }
}
