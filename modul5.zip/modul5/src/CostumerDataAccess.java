
public class CostumerDataAccess {
    public static void main(String[] args) {
        CostumerData co0 = new CostumerData();
        CostumerData co1 = new CostumerData("Bambang");
        CostumerData co2 = new CostumerData("Samin", "Delanggu");
        CostumerData co3 = new CostumerData("Bambang", "Madiun", "08-21-1945");
        CostumerData co4 = new CostumerData("Joko", "Sragen", "07-07-1977", "Kang Somay");
        CostumerData co5 = new CostumerData("Yudi", "Kleco");
        CostumerData co6 = new CostumerData("Arman");
        CostumerData co7 = new CostumerData("Agus", "Gawok");
        CostumerData co8 = new CostumerData("Berli", "Kostan", "11-02-2000", "Kang Parkir",5000);
        CostumerData co9 = new CostumerData("Muhammad Rafi", "Delanggu", "11-02-2000", "Mahasiswa",9000000);
        co1.info();
        System.out.println("---------------------------------------------------------------------------");
        co9.info();
        
    }
}
