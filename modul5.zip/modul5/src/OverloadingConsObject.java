
public class OverloadingConsObject {
    public static void main(String[] args) {
        OverloadingCons id1 = new OverloadingCons(138);
        OverloadingCons id2 = new OverloadingCons(138,"Muhammad Rafi",99,new java.util.Date(System.currentTimeMillis()));
        id1.infoku();
        System.out.println("----------------------------------------------");
        id2.infoku();
    }
}
