/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Acer
 */
public class Modul3 {
    int nilaiMID;
    int nilaiTugas;
    int nilaiUAS;
    Double x = new Double(nilaiMID);
    Double y = new Double(nilaiTugas);
    Double z = new Double(nilaiUAS);
    
    
    public double nilaimid(double nilaimid){
        return this.x = nilaimid;
    }
    public double nilaitugas(double nilaitugas){
        return this.y = nilaitugas;
    }
    public double nilaiuas(double nilaiuas){
        return this.z = nilaiuas;
    }
    public void totalNilai(double nilaiMID, double nilaiTugas, double nilaiUAS){
        this.x = nilaiMID;
        this.y = nilaiTugas;
        this.z = nilaiUAS;
    }
    public void infoNilai(){
        double nilaiTotal = (x + y + z)/3;
        System.out.println("Nilai Total Anda : " +nilaiTotal);
    }
    public static void main(String[] args) {
        Modul3 nilai = new Modul3();
        nilai.totalNilai(95.50,95,90.50);
        nilai.infoNilai();
    }
    
}
