package mandiri;

public class BankPribadi extends Bank {
    @Override
    public int rasioBunga(){
        return 7;
    }
    public static void main(String[] args) {
        Bank pbd = new BankPribadi();
        pbd.rasioBunga();
        System.out.println("Rasio Bunga Bank Pribadi");
        System.out.println("Rasio Bunga : "+pbd.rasioBunga()+"%");
    }
}
