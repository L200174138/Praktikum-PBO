
package mandiri;

public class Bank {
    public int rasioBunga(){
        return 0;
    }
}
