
package umum;

public class BankSyariah extends BankUmum{
    @Override
    public int rasioBunga(){
        return 28;
    }
    public static void main(String[] args) {
        BankUmum syr = new BankSyariah();
        syr.rasioBunga();
        System.out.println("Rasio Bunga Bank Pasar");
        System.out.println("Rasio Bunga : "+syr.rasioBunga()+"%");
        System.out.println("=====================================");
        BankUmum psr = new BankPasar();
        System.out.println("Rasio Bunga Bank Pasar");
        System.out.println("Rasio Bunga : "+psr.rasioBunga()+"%");
    }
}
