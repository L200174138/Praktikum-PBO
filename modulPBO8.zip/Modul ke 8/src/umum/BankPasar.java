
package umum;

public class BankPasar extends BankUmum{
    @Override
    public int rasioBunga(){
        return 21;
    }
    public static void main(String[] args) {
        BankUmum psr = new BankPasar();
        psr.rasioBunga();
        System.out.println("Rasio Bunga Bank Pasar");
        System.out.println("Rasio Bunga : "+psr.rasioBunga()+"%");
        System.out.println("=====================================");
        BankUmum um = new BankUmum();
        psr.rasioBunga();
        System.out.println("Rasio Bunga Bank Pasar");
        System.out.println("Rasio Bunga : "+um.rasioBunga()+"%");
    }
}
