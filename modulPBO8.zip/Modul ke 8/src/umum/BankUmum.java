
package umum;
import mandiri.Bank;

public class BankUmum extends Bank{
    @Override
    public int rasioBunga(){
        return 15;
    }
}
