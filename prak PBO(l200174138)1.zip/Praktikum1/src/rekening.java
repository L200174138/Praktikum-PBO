/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author LAB-RPL
 */
public class rekening {
    String norek = "Nomor Rekening :L200174138";
    int saldo = 5000000;
    int menabung;
    int menarik;
    int transfer;
    
    
    void menabung(int tbg){
        menabung = menabung + tbg;
        saldo = saldo + menabung;
    }
    
    void menarik(int tar){
        menarik = menarik + tar;
        saldo = saldo - menarik;
        
    }
    
    void transfer(int tf){
        transfer = transfer + tf;
        saldo = saldo - transfer;
    }
    
    void dataStruk(){
        System.out.println(norek);
        System.out.println("Anda menyetor sejumlah : Rp. "+menabung);
        System.out.println("Anda menarik sejumlah : Rp. "+menarik);
        System.out.println("Anda transfer sejumlah : Rp. "+transfer);
        System.out.println("Saldo anda : Rp. "+saldo);
    }
    
}
    
    
    
    
