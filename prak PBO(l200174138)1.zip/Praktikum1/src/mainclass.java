/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author LAB-RPL
 */
public class mainclass {
  public static void main(String[] args){
      Rotiku rotienak = new Rotiku();
      Rotiku rotienak2 = new Rotiku();
      Rotiku rotienak3 = new Rotiku();
      rotienak.beriWarna("Cokelat");
      rotienak.beriRasa("Pisang Coklat");
      rotienak.timbangBerat(50);
      rotienak.hargaJual(5000);
      rotienak.infoRoti();
      
      rotienak.beriWarna("merah");
      rotienak.beriRasa("gulali");
      rotienak.timbangBerat(20);
      rotienak.hargaJual(3000);
      rotienak.infoRoti();
      
      rotienak.beriWarna("ungu");
      rotienak.beriRasa("ubi");
      rotienak.timbangBerat(70);
      rotienak.hargaJual(15000);
      rotienak.infoRoti();
      
      
      Bicycle bike1 = new Bicycle();
      Bicycle bike2 = new Bicycle();
      
      bike1.gantiCadance(50);
      bike1.speedUp(20);
      bike1.gantiGear(2);
      bike1.printInfo();
      bike1.gantiCadance(50);
      bike1.speedUp(20);
      bike1.gantiGear(2);
      bike1.gantiCadance(40);
      bike1.speedUp(10);
      bike1.gantiGear(1);
      bike1.printInfo();
      
      kucing meong = new kucing();
      meong.umurkucing(5);
      meong.warna("biru");
      meong.printInfo();
      
      rekening bank = new rekening();
        bank.menabung(50000);
        bank.menarik(200000);
        bank.transfer(500000);
        bank.dataStruk();
  }
}
