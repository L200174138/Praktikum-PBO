/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author LAB-RPL
 */
public class kucing {
    int umur;
    String warnaBulu;
    
    void umurkucing(int umur1){
        umur = umur1;
    }
    void warna(String bulu){
        warnaBulu = bulu;
    }
    void printInfo(){
        System.out.println(
        "Umur Kucing : "+umur+" tahun"+"\n"+
        "Warna Bulu Kucing :"+warnaBulu+"\n");
    }
}
