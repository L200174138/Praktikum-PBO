/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author LAB-RPL
 */
public class Bicycle {
    int changeCadance;
    int speedUp;
    int changeGear;
    
    void gantiCadance(int ChangeCadance){
        changeCadance = ChangeCadance;
    }
    void speedUp(int SpeedUp){
        speedUp = SpeedUp;
    }
    void gantiGear (int ChangeGear){
        changeGear = ChangeGear;
    }
    
    void printInfo(){
        System.out.println(
               "Change Gear : "+changeGear+"\n"+
               "Speed Up : "+speedUp+"\n"+
               "Change Cadance : "+changeCadance+"\n");
    }
}
