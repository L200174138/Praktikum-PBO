/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Acer
 */
import java.util.Scanner;

public class Kalimat {
    void bacaHuruf(){
        String huruf;
        Scanner input1 = new Scanner(System.in);
        System.out.println("Tuliskan kalimat : ");
        huruf = input1.nextLine();
        System.out.println("Jumlah karakter : " + huruf.length());
    }
    public static void main(String[] args) {
        Kalimat baca = new Kalimat();
        baca.bacaHuruf();
    }
    
}
