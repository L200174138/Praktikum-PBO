/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Acer
 */
public class Mahasiswa {
    String nama;
    String nim;
    String alamat;
    int semester;
    
    void tampilkanNama(){
        nama = "Muhammad Rafi";
        System.out.println("Nama Mahasiswa : "+nama);
    }
    
    void tampilkanNim(){
        nim = "L200174138";
        System.out.println("NIM Mahasiswa : "+nim);
    }
    
    void tampilkanAlamat(){
        alamat = "jl.raya delanggu raya";
        System.out.println("Alamat Mahasiswa : "+alamat);
    }
    
    void tampilkanSemester(){
        semester = 3;
        System.out.println("Semester Mahasiswa : "+semester);
    }
    
}
