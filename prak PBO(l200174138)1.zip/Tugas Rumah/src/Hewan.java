/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Acer
 */
public class Hewan {
    String nama;
    String kaki;
    String makanan;
    String type;
    
    void printState(){
        System.out.println("Nama Hewan : "+nama);
        System.out.println("Jumlah Kaki : "+kaki);
        System.out.println("Makanan : "+makanan);
        System.out.println("Type Hewan : "+type);
        System.out.println("------------------------------");
    }
    
    void hewan1(){
        nama = "Harimau";
        kaki = "4";
        makanan = "Daging";
        type = "Karnivora";
        printState();
    }
    
    void hewan2(){
        nama = "Kerbau";
        kaki = "4";
        makanan = "Rumput";
        type = "Herbivora";
        printState();
    }
    
    public static void main(String[] args) {
        Hewan hew = new Hewan();
        hew.hewan1();
        hew.hewan2();
    }
    
}
