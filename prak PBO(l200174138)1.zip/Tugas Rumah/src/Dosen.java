/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Acer
 */
public class Dosen {
    String nama;
    String pendidikan;
    String ttl;
    int nik;
    
    void tampilkanNama(){
        nama = "Bambang";
        System.out.println("Nama Dosen : "+nama);
    }
    
    void tampilkanNik (){
        nik = 80000;
        System.out.println("NIK Dosen : "+nik);
    }
    
    void tampilkanPendidikan(){
        pendidikan = "S3";
        System.out.println("Pendidikan Dosen : "+pendidikan);
    }
    
    void tampilkanTglLahir(){
        ttl = "21 Mei 1982";
        System.out.println("Tanggal lahir Dosen : "+ttl);
    }
    
}
